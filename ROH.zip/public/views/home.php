<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">
		<title>Início - Relatório Ocupação Hospitalar</title>
		<link rel="shortcut icon" type="x-icon" href="public/img/favicon-32x32.png" />
		<link rel="stylesheet" type="text/css" href="">
		<script src="https://code.jquery.com/jquery-3.6.0.slim.min.js" integrity="sha256-u7e5khyithlIdTpu22PHhENmPcRdFiHRjhAuHcs05RI=" crossorigin="anonymous"></script>
		<!-- <script src='js/lib/jquery-3.3.1.js?j=$r'></script> -->
		<script>
		</script>
	</head>
<body>

	<a href="app/Controller/LogoutController.php">Logout</a>
	<br>
	<a href="list.php">Administrar usuários</a>
	<br>
	<a href="novo.php">Administrar Metas</a>
	<br>
	<a href="hospital.php">Administrar Hospitais</a>

</body>
</html>
