INSERT INTO `_log_operacoes` (`id`, `usuarioId`, `acao`, `tabela`, `objetoId`, `ip`, `datahora`) VALUES ('1', '129', 'U', 'usuarios', '138', '', '2021-06-22 16:34:44');
INSERT INTO `_log_operacoes` (`id`, `usuarioId`, `acao`, `tabela`, `objetoId`, `ip`, `datahora`) VALUES ('2', '129', 'U', 'usuarios', '138', '', '2021-06-22 16:37:16');
INSERT INTO `_log_operacoes` (`id`, `usuarioId`, `acao`, `tabela`, `objetoId`, `ip`, `datahora`) VALUES ('3', '129', 'U', 'usuarios', '138', '', '2021-06-22 16:38:18');
INSERT INTO `_log_operacoes` (`id`, `usuarioId`, `acao`, `tabela`, `objetoId`, `ip`, `datahora`) VALUES ('4', '129', 'U', 'usuarios', '138', '', '2021-06-22 16:44:41');
